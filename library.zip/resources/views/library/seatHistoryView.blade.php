@extends('layouts.admin')
@section('content')
@php
use App\Models\Customers;
use App\Models\PlanType;
use Carbon\Carbon;
$today = Carbon::today();
@endphp

<div class="row">
    <!-- Main Info -->
    <div class="col-lg-12">
        <!-- Add Document -->
        <div class="card card-default main_card_content">
            <!-- /.card-header -->
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-lg-12">
                        <!-- <h4>Customer History for Seat {{ $seat->seat_no }}</h4> -->
                        <div class="table-responsive tableRemove_scroll">
                            @if($customers->isEmpty())
                            <p>No customer history found for this seat.</p>
                            @else
                            <table class="table table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Mobile</th>
                                        <th>Email</th>
                                        <th>Plan</th>
                                        <th>Plan Type</th>
                                        <th>Starts On</th>
                                        <th>Ends On</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($customers as $key => $value)
                                    @php
                                    $today = Carbon::today();
                                    $endDate = Carbon::parse($value->plan_end_date);
                                    $diffInDays = $today->diffInDays($endDate, false);
                                    @endphp
                                    <tr>
                                        <td><span class="uppercase truncate">{{$value->name}}</span></td>
                                        <td> {{$value->mobile}}</td>
                                        <td> {{$value->email }}</td>
                                        <td> {{$value->plan_name}}</td>
                                        <td> {{$value->plan_type_name}}</td>
                                        <td> {{$value->plan_start_date}}</td>
                                        <td> {{$value->plan_end_date}}<br>
                                            @if ($diffInDays > 0)
                                            <small class="text-success fs-10">Expires in {{ $diffInDays }} days</small>
                                            @elseif ($diffInDays < 0)
                                                <small class="text-danger fs-10">Expired {{ abs($diffInDays) }} days ago</small>
                                                @else
                                                <small class="text-warning fs-10">Expires today</small>
                                                @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection