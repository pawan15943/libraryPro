 <!-- Footer -->
 <footer>
    <div class="container">
        <div class=" text-center">
            <span>Copyright © 
                @php
                echo date('Y') ;
                @endphp 
           By NBCC </span>
        </div>
    </div>
</footer>

<!-- End of Footer -->